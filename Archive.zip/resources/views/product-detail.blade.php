{{-- <x-head/>
<div class="container mx-auto mt-10">
   <h1 class="text-2xl font-bold mb-4">{{ $product['title'] }}</h1>

   <img src="{{ $product['image']['src'] ?? '' }}" alt="{{ $product['title'] }}" class="w-1/3 mb-4">

   <p class="text-gray-700">{{ $product['body_html'] }}</p>
   <p class="text-lg font-semibold mt-2">Price: {{ $product['variants'][0]['price'] }} USD</p>

   <h3 class="mt-5 text-lg font-semibold">Choose Variant:</h3>
   <div class="flex gap-2">
       @foreach ($product['variants'] as $variant)
           <button 
               onclick="selectVariant({{ $variant['id'] }}, '{{ $variant['title'] }}', {{ $variant['price'] }})" 
               class="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded cursor-pointer">
               {{ $variant['title'] }}
           </button>
       @endforeach
   </div>


   <div class="">
       <input type="hidden" name="variant_id" id="variant_id" value="{{ $product['variants'][0]['id'] }}">
       <input type="hidden" name="variant_title" id="variant_title" value="{{ $product['variants'][0]['title'] }}">
       <input type="hidden" name="price" id="price" value="{{ $product['variants'][0]['price'] }}">

       <label for="quantity" class="block mt-3">Quantity:</label>
       <input type="number" name="quantity" id="quantity" value="1" min="1" class="border p-2">

       <button onclick="addToCart({{ $product['variants'][0]['id'] }}, '{{ $product['title'] }}', '{{ $product['images'][0]['src'] }}', document.getElementById('quantity').value)" class="px-4 py-2 bg-blue-500 text-white rounded mt-3">Add to Cart</button>
   </div>
</div>

<script>
   function addToCart(variantId, title, image, quantity) {
       fetch("/cart/add", {
           method: "POST",
           headers: {
               "Content-Type": "application/json",
               "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').getAttribute("content")
           },
           body: JSON.stringify({
               variant_id: variantId,
               title: title,
               image: image,
               quantity: 1
           })
       })
       .then(response => response.json())
       .then(data => {
           alert(data.message); // Notifikasi berhasil
       })
       .catch(error => {
           console.error("Error:", error);
       });
   }
</script>

<script>
   function selectVariant(id, title, price) {
       document.getElementById('variant_id').value = id;
       document.getElementById('variant_title').value = title;
       document.getElementById('price').value = price;
   }
</script> --}}


{{-- ################################################################## --}}

{{-- <x-head/>
<div class="container mx-auto mt-10">
   <h1 class="text-2xl font-bold mb-4">{{ $product['title'] }}</h1>

   <!-- Product Image -->
   <img src="{{ $product['image']['src'] ?? '' }}" alt="{{ $product['title'] }}" class="w-1/3 mb-4">

   <p class="text-gray-700">{!! $product['body_html'] !!}</p>
   <p class="text-lg font-semibold mt-2">
       Price: <span id="selected_price">{{ $product['variants'][0]['price'] }}</span> USD
   </p>

   <!-- Variants Selection -->
   <h3 class="mt-5 text-lg font-semibold">Choose Variant:</h3>
   <div class="flex gap-2 mt-2">
       @foreach ($product['variants'] as $variant)
           <label class="variant-label cursor-pointer px-4 py-2 bg-gray-200 rounded hover:bg-gray-300" onclick="selectVariant({{ $variant['id'] }}, '{{ $variant['title'] }}', {{ $variant['price'] }})">
               <input type="radio" name="variant" value="{{ $variant['id'] }}" class="hidden">
               {{ $variant['title'] }}
           </label>
       @endforeach
   </div>

   <!-- Hidden Inputs -->
   <input type="hidden" name="variant_id" id="variant_id" value="{{ $product['variants'][0]['id'] }}">
   <input type="hidden" name="variant_title" id="variant_title" value="{{ $product['variants'][0]['title'] }}">
   <input type="hidden" name="price" id="price" value="{{ $product['variants'][0]['price'] }}">

   <!-- Quantity Input -->
   <label for="quantity" class="block mt-3">Quantity:</label>
   <input type="number" name="quantity" id="quantity" value="1" min="1" class="border p-2">

   <!-- Add to Cart Button -->
   <button onclick="addToCart()" class="px-4 py-2 bg-blue-500 text-white rounded mt-3">Add to Cart</button>
</div>

<script>
   function selectVariant(id, title, price) {
       document.getElementById('variant_id').value = id;
       document.getElementById('variant_title').value = title;
       document.getElementById('price').value = price;
       document.getElementById('selected_price').innerText = price;

       // Update styling
       document.querySelectorAll('.variant-label').forEach(el => el.classList.remove('bg-blue-500', 'text-white'));
       event.target.classList.add('bg-blue-500', 'text-white');
   }

   function addToCart() {
       let variantId = document.getElementById('variant_id').value;
       let title = document.getElementById('variant_title').value;
       let price = document.getElementById('price').value;
       let quantity = document.getElementById('quantity').value;

       fetch("/cart/add", {
           method: "POST",
           headers: {
               "Content-Type": "application/json",
               "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').getAttribute("content")
           },
           body: JSON.stringify({
               variant_id: variantId,
               title: title,
               price: price,
               quantity: quantity
           })
       })
       .then(response => response.json())
       .then(data => {
           alert(data.message); // Notifikasi berhasil
       })
       .catch(error => {
           console.error("Error:", error);
       });
   }
</script> --}}

{{-- ############################################################# --}}

{{-- <x-head />
<div class="container mx-auto mt-10">
    <h1 class="text-2xl font-bold mb-4">{{ $product['title'] }}</h1>

    <!-- Product Image -->
    <img src="{{ $product['image']['src'] ?? '' }}" alt="{{ $product['title'] }}" class="w-1/3 mb-4">

    <p class="text-gray-700">{!! $product['body_html'] !!}</p>
    <p class="text-lg font-semibold mt-2">
        Price: <span id="selected_price">{{ $product['variants'][0]['price'] }}</span> USD
    </p>

    <!-- Variants Selection -->
    <h3 class="mt-5 text-lg font-semibold">Choose Variant:</h3>
    <div class="grid grid-cols-7 gap-2 mt-2">
        @foreach ($product['variants'] as $variant)
            <label class="variant-label cursor-pointer px-4 py-2 rounded transition
                          {{ $loop->first ? 'bg-red-500 text-white' : 'bg-gray-200 hover:border-2' }}
                          {{ $variant['inventory_quantity'] <= 0 ? 'cursor-not-allowed opacity-50' : '' }}"
                   onclick="selectVariant({{ $variant['id'] }}, '{{ $variant['title'] }}', {{ $variant['price'] }}, {{ $variant['inventory_quantity'] }}, this)"
                   data-id="{{ $variant['id'] }}" data-stock="{{ $variant['inventory_quantity'] }}">
                <input type="radio" name="variant" value="{{ $variant['id'] }}" class="hidden"
                       {{ $variant['inventory_quantity'] <= 0 ? 'disabled' : '' }}>
                {{ $variant['title'] }}
                @if ($variant['inventory_quantity'] <= 0)
                    <span class="text-red-500 text-xs">(Out of Stock)</span>
                @endif
            </label>
        @endforeach
    </div>

    <!-- Hidden Inputs -->
    <input type="hidden" name="variant_id" id="variant_id" value="{{ $product['variants'][0]['id'] }}">
    <input type="hidden" name="variant_title" id="variant_title" value="{{ $product['variants'][0]['title'] }}">
    <input type="hidden" name="price" id="price" value="{{ $product['variants'][0]['price'] }}">
    <input type="hidden" name="stock" id="stock" value="{{ $product['variants'][0]['inventory_quantity'] }}">

    <!-- Quantity Input -->
    <label for="quantity" class="block mt-3">Quantity:</label>
    <input type="number" name="quantity" id="quantity" value="1" min="1" class="border p-2">

    <!-- Add to Cart Button -->
    <button onclick="addToCart()" id="addToCartBtn" class="px-4 py-2 bg-blue-500 text-white rounded mt-3">Add to Cart</button>
</div>

<script>
    function selectVariant(id, title, price, stock, element) {
        if (stock <= 0) return;

        document.getElementById('variant_id').value = id;
        document.getElementById('variant_title').value = title;
        document.getElementById('price').value = price;
        document.getElementById('stock').value = stock;
        document.getElementById('selected_price').innerText = price;

        // Reset styling
        document.querySelectorAll('.variant-label').forEach(el => el.classList.remove('bg-red-500', 'text-white'));

        // Tandai varian terpilih dengan warna merah
        element.classList.add('bg-red-500', 'text-white');

        // Cek stok
        document.getElementById('addToCartBtn').disabled = stock <= 0;
        document.getElementById('addToCartBtn').classList.toggle('opacity-50', stock <= 0);
    }

    function addToCart() {
        let variantId = document.getElementById('variant_id').value;
        let title = document.getElementById('variant_title').value;
        let price = document.getElementById('price').value;
        let quantity = document.getElementById('quantity').value;
        let stock = document.getElementById('stock').value;

        if (stock <= 0) {
            alert("This variant is out of stock.");
            return;
        }

        fetch("/cart/add", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').getAttribute("content")
            },
            body: JSON.stringify({
                variant_id: variantId,
                title: title,
                price: price,
                quantity: quantity
            })
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
        })
        .catch(error => {
            console.error("Error:", error);
        });
    }
</script> --}}


{{-- lorem --}}

{{-- <x-head />
<div class="container mx-auto mt-10">
    <h1 class="text-2xl font-bold mb-4">{{ $product['title'] }}</h1>

    <!-- Product Image -->
    <img src="{{ $product['image']['src'] ?? '' }}" alt="{{ $product['title'] }}" class="w-1/3 mb-4">

    <p class="text-gray-700">{!! $product['body_html'] !!}</p>
    <p class="text-lg font-semibold mt-2">
        Price: <span id="selected_price">{{ $product['variants'][0]['price'] }}</span> USD
    </p>

    <!-- Dynamic Variant Selections -->
    <div id="variantSelections"></div>

    <!-- Hidden Inputs -->
    <input type="hidden" name="variant_id" id="variant_id" value="">
    <input type="hidden" name="variant_title" id="variant_title" value="">
    <input type="hidden" name="price" id="price" value="">
    <input type="hidden" name="stock" id="stock" value="">

    <!-- Quantity Input -->
    <label for="quantity" class="block mt-3">Quantity:</label>
    <input type="number" name="quantity" id="quantity" value="1" min="1" class="border p-2" disabled>

    <!-- Add to Cart Button -->
    <button onclick="addToCart()" id="addToCartBtn" class="px-4 py-2 bg-blue-500 text-white rounded mt-3 opacity-50" disabled>
        Add to Cartss
    </button>
</div>

<script>
    let productVariants = @json($product['variants']);
    let selectedOptions = {};
    let variantOptions = @json(collect($product['variants'])->map(fn($v) => [$v['option1'], $v['option2'], $v['option3']])->unique()->values());

    function renderVariantSelectors() {
        let container = document.getElementById('variantSelections');
        container.innerHTML = '';

        let variantNames = Object.keys(variantOptions[0]).filter(k => variantOptions.some(v => v[k]));

        variantNames.forEach((variantName, index) => {
            let availableOptions = [...new Set(productVariants.map(v => v[`option${index + 1}`]).filter(o => o))];

            let html = `
                <h3 class="mt-5 text-lg font-semibold">Choose ${variantName}:</h3>
                <div class="flex gap-2 mt-2" id="variant_${index}">
                    ${availableOptions.map(option => {
                        let isAvailable = productVariants.some(v => v[`option${index + 1}`] === option && v.inventory_quantity > 0);
                        let disabledClass = isAvailable ? 'cursor-pointer bg-gray-200 hover:bg-gray-300' : 'bg-gray-400 cursor-not-allowed opacity-50';
                        
                        return `
                            <label class="variant-label px-4 py-2 rounded transition ${disabledClass}"
                                   onclick="selectVariant(${index}, '${option}')"
                                   data-variant-index="${index}" data-option="${option}"
                                   ${isAvailable ? '' : 'disabled'}>
                                <input type="radio" name="variant_${index}" value="${option}" class="hidden">
                                ${option}
                            </label>
                        `;
                    }).join('')}
                </div>
            `;

            container.innerHTML += html;
        });
    }

    function selectVariant(index, option) {
        let optionElement = event.target.closest('.variant-label');

        if (optionElement.classList.contains('cursor-not-allowed')) return;

        selectedOptions[index] = option;

        document.querySelectorAll(`[data-variant-index="${index}"]`).forEach(el => el.classList.remove('bg-red-500', 'text-white'));
        optionElement.classList.add('bg-red-500', 'text-white');

        updateAvailableOptions(index);
    }

    function updateAvailableOptions(selectedIndex) {
        Object.keys(selectedOptions).forEach((index) => {
            if (index > selectedIndex) {
                delete selectedOptions[index];
                document.getElementById(`variant_${index}`).innerHTML = '<p class="text-gray-500">Please select previous options first.</p>';
            }
        });

        let filteredVariants = productVariants.filter(variant => {
            return Object.keys(selectedOptions).every(index => variant[`option${+index + 1}`] === selectedOptions[index]);
        });

        let nextIndex = selectedIndex + 1;
        let nextOptions = [...new Set(filteredVariants.map(v => v[`option${nextIndex + 1}`]).filter(o => o))];

        if (nextOptions.length > 0) {
            let nextContainer = document.getElementById(`variant_${nextIndex}`);
            nextContainer.innerHTML = nextOptions.map(option => {
                let isAvailable = filteredVariants.some(v => v[`option${nextIndex + 1}`] === option && v.inventory_quantity > 0);
                let disabledClass = isAvailable ? 'cursor-pointer bg-gray-200 hover:bg-gray-300' : 'bg-gray-400 cursor-not-allowed opacity-50';

                return `
                    <label class="variant-label px-4 py-2 rounded transition ${disabledClass}"
                           onclick="selectVariant(${nextIndex}, '${option}')"
                           data-variant-index="${nextIndex}" data-option="${option}"
                           ${isAvailable ? '' : 'disabled'}>
                        <input type="radio" name="variant_${nextIndex}" value="${option}" class="hidden">
                        ${option}
                    </label>
                `;
            }).join('');
        } else {
            let selectedVariant = filteredVariants.length > 0 ? filteredVariants[0] : null;
            if (selectedVariant) {
                document.getElementById('variant_id').value = selectedVariant.id;
                document.getElementById('variant_title').value = Object.values(selectedOptions).join(' - ');
                document.getElementById('price').value = selectedVariant.price;
                document.getElementById('stock').value = selectedVariant.inventory_quantity;
                document.getElementById('selected_price').innerText = selectedVariant.price;

                document.getElementById('quantity').disabled = false;
                document.getElementById('addToCartBtn').disabled = false;
                document.getElementById('addToCartBtn').classList.remove('opacity-50');
            }
        }
    }

    renderVariantSelectors();
</script>

 --}}


 <x-head />
<div class="container mx-auto mt-10 mb-20 flex gap-10">
    <div class="w-[50%]">
        <h1 class="text-2xl font-bold mb-10" id="">{{ $product['title'] }}</h1>
        <img id="imageproduct" src="{{ $product['image']['src'] ?? '' }}" alt="{{ $product['title'] }}" class="w-full h-[60vh] object-contain object-center">
    </div>

    <div class="w-[50%] flex flex-col justify-center w-max">
        <p class="text-gray-700">{!! $product['body_html'] !!}</p>
        <p class="text-lg font-semibold mt-2">
            Price: <span id="selected_price">{{ $product['variants'][0]['price'] }}</span> USD
        </p>

        <!-- Dynamic Variant Selections -->
        <div id="variantSelections"></div>

        <!-- Hidden Inputs -->
        <input type="hidden" name="justtitle" value="{{ $product['title'] }}" id="justtitle">
        <input type="hidden" name="variant_id" id="variant_id" value="">
        <input type="hidden" name="variant_title" id="variant_title" value="">
        <input type="hidden" name="price" id="price" value="">
        <input type="hidden" name="stock" id="stock" value="">

        <div class="flex gap-5 mt-5 items-end">
            <div class="">
                <label for="quantity" class="block mt-3">Quantity:</label>
                <input type="number" name="quantity" id="quantity" value="1" min="1" class="border p-2" disabled>
            </div>
            
            <!-- Add to Cart Button -->
            <button onclick="addToCart()" id="addToCartBtn" class="px-4 py-2 bg-blue-500 text-white rounded mt-3 opacity-50" disabled>
                Add to Cart
            </button>
        </div>
    </div>
</div>

{{-- <script>
    let productVariants = @json($product['variants']);
    let selectedOptions = {};
    let variantOptions = @json(collect($product['variants'])->map(fn($v) => [$v['option1'], $v['option2'], $v['option3']])->unique()->values());

    function renderVariantSelectors() {
        let container = document.getElementById('variantSelections');
        container.innerHTML = '';

        let variantNames = Object.keys(variantOptions[0]).filter(k => variantOptions.some(v => v[k]));

        variantNames.forEach((variantName, index) => {
            let availableOptions = [...new Set(productVariants.map(v => v[`option${index + 1}`]).filter(o => o))];

            let html = `
                <h3 class="mt-5 text-lg font-semibold">Choose ${variantName}:</h3>
                <div class="flex gap-2 mt-2" id="variant_${index}">
                    ${availableOptions.map(option => {
                        let isAvailable = productVariants.some(v => v[`option${index + 1}`] === option && v.inventory_quantity > 0);
                        let disabledClass = isAvailable ? 'cursor-pointer bg-gray-200 hover:bg-gray-300' : 'bg-gray-400 cursor-not-allowed opacity-50';
                        
                        return `
                            <label class="variant-label px-4 py-2 rounded transition ${disabledClass}"
                                   onclick="selectVariant(${index}, '${option}')"
                                   data-variant-index="${index}" data-option="${option}"
                                   ${isAvailable ? '' : 'disabled'}>
                                <input type="radio" name="variant_${index}" value="${option}" class="hidden">
                                ${option}
                            </label>
                        `;
                    }).join('')}
                </div>
            `;

            container.innerHTML += html;
        });
    }

    function selectVariant(index, option) {
        let optionElement = event.target.closest('.variant-label');

        if (optionElement.classList.contains('cursor-not-allowed')) return;

        selectedOptions[index] = option;

        document.querySelectorAll(`[data-variant-index="${index}"]`).forEach(el => el.classList.remove('bg-red-500', 'text-white'));
        optionElement.classList.add('bg-red-500', 'text-white');

        updateAvailableOptions(index);
    }

    function updateAvailableOptions(selectedIndex) {
        Object.keys(selectedOptions).forEach((index) => {
            if (index > selectedIndex) {
                delete selectedOptions[index];
                document.getElementById(`variant_${index}`).innerHTML = '<p class="text-gray-500">Please select previous options first.</p>';
            }
        });

        let filteredVariants = productVariants.filter(variant => {
            return Object.keys(selectedOptions).every(index => variant[`option${+index + 1}`] === selectedOptions[index]);
        });

        let nextIndex = selectedIndex + 1;
        let nextOptions = [...new Set(filteredVariants.map(v => v[`option${nextIndex + 1}`]).filter(o => o))];

        if (nextOptions.length > 0) {
            let nextContainer = document.getElementById(`variant_${nextIndex}`);
            nextContainer.innerHTML = nextOptions.map(option => {
                let isAvailable = filteredVariants.some(v => v[`option${nextIndex + 1}`] === option && v.inventory_quantity > 0);
                let disabledClass = isAvailable ? 'cursor-pointer bg-gray-200 hover:bg-gray-300' : 'bg-gray-400 cursor-not-allowed opacity-50';

                return `
                    <label class="variant-label px-4 py-2 rounded transition ${disabledClass}"
                           onclick="selectVariant(${nextIndex}, '${option}')"
                           data-variant-index="${nextIndex}" data-option="${option}"
                           ${isAvailable ? '' : 'disabled'}>
                        <input type="radio" name="variant_${nextIndex}" value="${option}" class="hidden">
                        ${option}
                    </label>
                `;
            }).join('');
        } else {
            let selectedVariant = filteredVariants.length > 0 ? filteredVariants[0] : null;

            if (selectedVariant) {
                document.getElementById('variant_id').value = selectedVariant.id;
                document.getElementById('variant_title').value = Object.values(selectedOptions).join(' - ');
                document.getElementById('price').value = selectedVariant.price;
                document.getElementById('stock').value = selectedVariant.inventory_quantity;
                document.getElementById('selected_price').innerText = selectedVariant.price;

                console.log('Selected Variant:', selectedVariant);
                console.log('Variant ID:', selectedVariant.id);
                console.log('Stock:', selectedVariant.inventory_quantity);

                if (selectedVariant.inventory_quantity > 0) {
                    document.getElementById('quantity').disabled = false;
                    document.getElementById('addToCartBtn').disabled = false;
                    document.getElementById('addToCartBtn').classList.remove('opacity-50');
                } else {
                    document.getElementById('quantity').disabled = true;
                    document.getElementById('addToCartBtn').disabled = true;
                    document.getElementById('addToCartBtn').classList.add('opacity-50');
                }
            }
        }
    }

    function addToCart() {
    let variantId = document.getElementById('variant_id').value;
    let variantTitle = document.getElementById('variant_title').value;
    let titles = document.getElementById('justtitle').value; // Assuming you want the value from this element
    let img = document.getElementById('imageproduct').src;
    let quantity = document.getElementById('quantity').value;

    if (!variantId) {
        alert('Please select a variant before adding to cart.');
        return;
    }

    fetch('/cart/add', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        },
        body: JSON.stringify({
            variant_id: variantId,
            title:  titles + ' - ' + variantTitle,
            image: img,
            quantity: quantity
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.message === 'Added to cart') {
            alert('Item added to cart successfully!');
            console.log('Updated Cart:', data.cart);
        } else {
            alert('Failed to add to cart.');
        }
    })
    .catch(error => console.error('Error:', error));
}

    renderVariantSelectors();
</script> --}}


{{-- fix in 3 category --}}
{{-- <script>
    let productVariants = @json($product['variants']);
    let selectedOptions = {};
    let variantOptions = @json(collect($product['variants'])->map(fn($v) => [$v['option1'], $v['option2'], $v['option3']])->unique()->values());

    function renderVariantSelectors() {
        let container = document.getElementById('variantSelections');
        container.innerHTML = '';

        let variantNames = Object.keys(variantOptions[0]).filter(k => variantOptions.some(v => v[k]));

        variantNames.forEach((variantName, index) => {
            let availableOptions = [...new Set(productVariants.map(v => v[`option${index + 1}`]).filter(o => o))];

            let html = `
                <h3 class="mt-5 text-lg font-semibold">Choose ${variantName}:</h3>
                <div class="flex gap-2 mt-2" id="variant_${index}">
                    ${availableOptions.map(option => {
                        let isAvailable = productVariants.some(v => v[`option${index + 1}`] === option && v.inventory_quantity > 0);
                        let disabledClass = isAvailable ? 'cursor-pointer bg-gray-200 hover:bg-gray-300' : 'bg-gray-400 cursor-not-allowed opacity-50';
                        
                        return `
                            <label class="variant-label px-4 py-2 rounded transition ${disabledClass}"
                                   onclick="selectVariant(${index}, '${option}')"
                                   data-variant-index="${index}" data-option="${option}"
                                   ${isAvailable ? '' : 'disabled'}>
                                <input type="radio" name="variant_${index}" value="${option}" class="hidden">
                                ${option}
                            </label>
                        `;
                    }).join('')}
                </div>
            `;

            container.innerHTML += html;
        });

        checkIfAllVariantsSelected();
    }

    function selectVariant(index, option) {
        let optionElement = event.target.closest('.variant-label');

        if (optionElement.classList.contains('cursor-not-allowed')) return;

        selectedOptions[index] = option;

        document.querySelectorAll(`[data-variant-index="${index}"]`).forEach(el => el.classList.remove('bg-red-500', 'text-white'));
        optionElement.classList.add('bg-red-500', 'text-white');

        updateAvailableOptions(index);
        checkIfAllVariantsSelected();
    }

    function updateAvailableOptions(selectedIndex) {
        Object.keys(selectedOptions).forEach((index) => {
            if (index > selectedIndex) {
                delete selectedOptions[index];
                document.getElementById(`variant_${index}`).innerHTML = '<p class="text-gray-500">Please select previous options first.</p>';
            }
        });

        let filteredVariants = productVariants.filter(variant => {
            return Object.keys(selectedOptions).every(index => variant[`option${+index + 1}`] === selectedOptions[index]);
        });

        let nextIndex = selectedIndex + 1;
        let nextOptions = [...new Set(filteredVariants.map(v => v[`option${nextIndex + 1}`]).filter(o => o))];

        if (nextOptions.length > 0) {
            let nextContainer = document.getElementById(`variant_${nextIndex}`);
            nextContainer.innerHTML = nextOptions.map(option => {
                let isAvailable = filteredVariants.some(v => v[`option${nextIndex + 1}`] === option && v.inventory_quantity > 0);
                let disabledClass = isAvailable ? 'cursor-pointer bg-gray-200 hover:bg-gray-300' : 'bg-gray-400 cursor-not-allowed opacity-50';

                return `
                    <label class="variant-label px-4 py-2 rounded transition ${disabledClass}"
                           onclick="selectVariant(${nextIndex}, '${option}')"
                           data-variant-index="${nextIndex}" data-option="${option}"
                           ${isAvailable ? '' : 'disabled'}>
                        <input type="radio" name="variant_${nextIndex}" value="${option}" class="hidden">
                        ${option}
                    </label>
                `;
            }).join('');
        } else {
            let selectedVariant = filteredVariants.length > 0 ? filteredVariants[0] : null;

            if (selectedVariant) {
                document.getElementById('variant_id').value = selectedVariant.id;
                document.getElementById('variant_title').value = Object.values(selectedOptions).join(' - ');
                document.getElementById('price').value = selectedVariant.price;
                document.getElementById('stock').value = selectedVariant.inventory_quantity;
                document.getElementById('selected_price').innerText = selectedVariant.price;

                if (selectedVariant.inventory_quantity > 0) {
                    document.getElementById('quantity').disabled = false;
                } else {
                    document.getElementById('quantity').disabled = true;
                }
            }
        }

        checkIfAllVariantsSelected();
    }

    function checkIfAllVariantsSelected() {
        let variantCount = Object.keys(variantOptions[0]).length;
        let isAllSelected = Object.keys(selectedOptions).length === variantCount;

        let addToCartBtn = document.getElementById('addToCartBtn');

        if (isAllSelected) {
            addToCartBtn.disabled = false;
            addToCartBtn.classList.remove('opacity-50');
        } else {
            addToCartBtn.disabled = true;
            addToCartBtn.classList.add('opacity-50');
        }
    }

    function addToCart() {
        let variantId = document.getElementById('variant_id').value;
        let variantTitle = document.getElementById('variant_title').value;
        let titles = document.getElementById('justtitle').value;
        let img = document.getElementById('imageproduct').src;
        let quantity = document.getElementById('quantity').value;

        if (!variantId) {
            alert('Please select a variant before adding to cart.');
            return;
        }

        fetch('/cart/add', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            body: JSON.stringify({
                variant_id: variantId,
                title: titles + ' - ' + variantTitle,
                image: img,
                quantity: quantity
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Added to cart') {
                alert('Item added to cart successfully!');
                console.log('Updated Cart:', data.cart);
            } else {
                alert('Failed to add to cart.');
            }
        })
        .catch(error => console.error('Error:', error));
    }

    renderVariantSelectors();
</script> --}}


<script>
    let productVariants = @json($product['variants']);
    let selectedOptions = {};

    // Hitung jumlah kategori varian yang tersedia (1, 2, atau 3)
    function getVariantCount() {
        let count = 0;
        if (productVariants.some(v => v.option1)) count++;
        if (productVariants.some(v => v.option2)) count++;
        if (productVariants.some(v => v.option3)) count++;
        return count;
    }

    function renderVariantSelectors() {
        let container = document.getElementById('variantSelections');
        container.innerHTML = '';

        let variantNames = ['option1', 'option2', 'option3'].filter(option => 
            productVariants.some(v => v[option] !== null)
        );

        variantNames.forEach((variantName, index) => {
            let availableOptions = [...new Set(productVariants.map(v => v[variantName]).filter(o => o))];

            let html = `
                <h3 class="mt-5 text-lg font-semibold">Choose ${variantName}:</h3>
                <div class="flex gap-2 mt-2" id="variant_${index}">
                    ${availableOptions.map(option => {
                        let isAvailable = productVariants.some(v => v[variantName] === option && v.inventory_quantity > 0);
                        let disabledClass = isAvailable ? 'cursor-pointer bg-gray-200 hover:bg-gray-300' : 'bg-gray-400 cursor-not-allowed opacity-50';
                        
                        return `
                            <label class="variant-label px-4 py-2 rounded transition ${disabledClass}"
                                   onclick="selectVariant(${index}, '${option}')"
                                   data-variant-index="${index}" data-option="${option}"
                                   ${isAvailable ? '' : 'disabled'}>
                                <input type="radio" name="variant_${index}" value="${option}" class="hidden">
                                ${option}
                            </label>
                        `;
                    }).join('')}
                </div>
            `;

            container.innerHTML += html;
        });

        checkIfAllVariantsSelected();
    }

    function selectVariant(index, option) {
        let optionElement = event.target.closest('.variant-label');

        if (optionElement.classList.contains('cursor-not-allowed')) return;

        selectedOptions[index] = option;

        document.querySelectorAll(`[data-variant-index="${index}"]`).forEach(el => el.classList.remove('bg-red-500', 'text-white'));
        optionElement.classList.add('bg-red-500', 'text-white');

        updateAvailableOptions(index);
        checkIfAllVariantsSelected();
    }

    function updateAvailableOptions(selectedIndex) {
        Object.keys(selectedOptions).forEach((index) => {
            if (index > selectedIndex) {
                delete selectedOptions[index];
                document.getElementById(`variant_${index}`).innerHTML = '<p class="text-gray-500">Please select previous options first.</p>';
            }
        });

        let filteredVariants = productVariants.filter(variant => {
            return Object.keys(selectedOptions).every(index => variant[`option${+index + 1}`] === selectedOptions[index]);
        });

        let nextIndex = selectedIndex + 1;
        let nextOptions = [...new Set(filteredVariants.map(v => v[`option${nextIndex + 1}`]).filter(o => o))];

        if (nextOptions.length > 0) {
            let nextContainer = document.getElementById(`variant_${nextIndex}`);
            nextContainer.innerHTML = nextOptions.map(option => {
                let isAvailable = filteredVariants.some(v => v[`option${nextIndex + 1}`] === option && v.inventory_quantity > 0);
                let disabledClass = isAvailable ? 'cursor-pointer bg-gray-200 hover:bg-gray-300' : 'bg-gray-400 cursor-not-allowed opacity-50';

                return `
                    <label class="variant-label px-4 py-2 rounded transition ${disabledClass}"
                           onclick="selectVariant(${nextIndex}, '${option}')"
                           data-variant-index="${nextIndex}" data-option="${option}"
                           ${isAvailable ? '' : 'disabled'}>
                        <input type="radio" name="variant_${nextIndex}" value="${option}" class="hidden">
                        ${option}
                    </label>
                `;
            }).join('');
        } else {
            let selectedVariant = filteredVariants.length > 0 ? filteredVariants[0] : null;

            if (selectedVariant) {
                document.getElementById('variant_id').value = selectedVariant.id;
                document.getElementById('variant_title').value = Object.values(selectedOptions).join(' - ');
                document.getElementById('price').value = selectedVariant.price;
                document.getElementById('stock').value = selectedVariant.inventory_quantity;
                document.getElementById('selected_price').innerText = selectedVariant.price;

                if (selectedVariant.inventory_quantity > 0) {
                    document.getElementById('quantity').disabled = false;
                } else {
                    document.getElementById('quantity').disabled = true;
                }
            }
        }

        checkIfAllVariantsSelected();
    }

    function checkIfAllVariantsSelected() {
        let variantCount = getVariantCount(); // Jumlah kategori varian
        let isAllSelected = Object.keys(selectedOptions).length === variantCount;

        let addToCartBtn = document.getElementById('addToCartBtn');

        if (isAllSelected) {
            addToCartBtn.disabled = false;
            addToCartBtn.classList.remove('opacity-50');
        } else {
            addToCartBtn.disabled = true;
            addToCartBtn.classList.add('opacity-50');
        }
    }

    function addToCart() {
        let variantId = document.getElementById('variant_id').value;
        let variantTitle = document.getElementById('variant_title').value;
        let titles = document.getElementById('justtitle').value;
        let img = document.getElementById('imageproduct').src;
        let quantity = document.getElementById('quantity').value;

        if (!variantId) {
            alert('Please select a variant before adding to cart.');
            return;
        }

        fetch('/cart/add', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            body: JSON.stringify({
                variant_id: variantId,
                title: titles + ' - ' + variantTitle,
                image: img,
                quantity: quantity
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Added to cart') {
                alert('Item added to cart successfully!');
                console.log('Updated Cart:', data.cart);
            } else {
                alert('Failed to add to cart.');
            }
        })
        .catch(error => console.error('Error:', error));
    }

    renderVariantSelectors();
</script>
