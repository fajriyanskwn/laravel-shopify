
<?php if (isset($component)) { $__componentOriginal0f509fab02c45445826003a1e50db506 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f509fab02c45445826003a1e50db506 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f509fab02c45445826003a1e50db506)): ?>
<?php $attributes = $__attributesOriginal0f509fab02c45445826003a1e50db506; ?>
<?php unset($__attributesOriginal0f509fab02c45445826003a1e50db506); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f509fab02c45445826003a1e50db506)): ?>
<?php $component = $__componentOriginal0f509fab02c45445826003a1e50db506; ?>
<?php unset($__componentOriginal0f509fab02c45445826003a1e50db506); ?>
<?php endif; ?>
<div class="container mx-auto mt-10">
   <h1 class="text-2xl font-bold mb-5">Shopping Cart</h1>

   <?php if(session('success')): ?>
       <div class="bg-green-100 p-3 text-green-700 mb-4"><?php echo e(session('success')); ?></div>
   <?php endif; ?>

   <?php if(count($cart) > 0): ?>
       <table class="w-full border-collapse border border-gray-300">
           <thead>
               <tr class="bg-gray-200">
                   <th class="p-3 border">img</th>
                   <th class="p-3 border">title</th>
                   <th class="p-3 border">Variant ID</th>
                   <th class="p-3 border">Quantity</th>
                   <th class="p-3 border">Actions</th>
               </tr>
           </thead>
           <tbody>
               <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr class="border">
                       <td class="p-3 border"><img src="<?php echo e($item['img']); ?>" alt="" class="w-16 h-16"></td>
                       <td class="p-3 border"><?php echo e($item['title']); ?></td>
                       <td class="p-3 border"><?php echo e($item['variant_id']); ?></td>
                       <td class="p-3 border flex items-center justify-center space-x-2">
                           <button 
                               onclick="updateQuantity(<?php echo e($item['variant_id']); ?>, -1)" 
                               class="px-2 py-1 bg-gray-300 text-black rounded">−</button>
                           <span id="quantity-<?php echo e($item['variant_id']); ?>"><?php echo e($item['quantity']); ?></span>
                           <button 
                               onclick="updateQuantity(<?php echo e($item['variant_id']); ?>, 1)" 
                               class="px-2 py-1 bg-gray-300 text-black rounded">+</button>
                       </td>
                       <td class="p-3 border">
                           <form action="<?php echo e(route('cart.remove')); ?>" method="POST" class="inline">
                               <?php echo csrf_field(); ?>
                               <input type="hidden" name="variant_id" value="<?php echo e($item['variant_id']); ?>">
                               <button type="submit" class="px-3 py-1 bg-red-500 text-white rounded">Remove</button>
                           </form>
                       </td>
                   </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </tbody>
       </table>

       <div class="mt-5">
           <form action="<?php echo e(route('cart.checkout')); ?>" method="POST">
               <?php echo csrf_field(); ?>
               <button type="submit" class="px-4 py-2 bg-blue-500 text-white rounded cursor-pointer hover:bg-red-700">Proceed to Checkout</button>
           </form>
       </div>
   <?php else: ?>
       <p>Your cart is empty.</p>
   <?php endif; ?>
</div>
<script>
    function updateQuantity(variantId, change) {
    let quantityElement = document.getElementById(`quantity-${variantId}`);
    let newQuantity = parseInt(quantityElement.innerText) + change;

    if (newQuantity < 1) return; // Jangan izinkan quantity lebih kecil dari 1

    fetch("<?php echo e(route('cart.update')); ?>", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').getAttribute("content")
        },
        body: JSON.stringify({
            variant_id: variantId,
            quantity: newQuantity
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            quantityElement.innerText = newQuantity; // Update tampilannya
        }
    })
    .catch(error => {
        console.error("Error:", error);
    });
}

</script>
    
    <?php /**PATH /Users/fajriyannur/localServer/www/shopify/resources/views/cart.blade.php ENDPATH**/ ?>