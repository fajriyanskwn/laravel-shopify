<?php if (isset($component)) { $__componentOriginal0f509fab02c45445826003a1e50db506 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f509fab02c45445826003a1e50db506 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f509fab02c45445826003a1e50db506)): ?>
<?php $attributes = $__attributesOriginal0f509fab02c45445826003a1e50db506; ?>
<?php unset($__attributesOriginal0f509fab02c45445826003a1e50db506); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f509fab02c45445826003a1e50db506)): ?>
<?php $component = $__componentOriginal0f509fab02c45445826003a1e50db506; ?>
<?php unset($__componentOriginal0f509fab02c45445826003a1e50db506); ?>
<?php endif; ?>
<body class="container mx-auto">
    <div class="p-6 bg-gray-100 rounded-lg shadow-md">
        <h1 class="text-2xl font-bold mb-5">Shopping Cart</h1>
    
        <div class="mt-6 grid grid-cols-4 gap-4">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="p-4 bg-white rounded-lg shadow">
                <img src="<?php echo e($product['images'][0]['src']); ?>" alt="<?php echo e($product['title']); ?>" class="w-full h-[300px] object-cover rounded-lg">
                <h2 class="text-xl font-semibold text-gray-900 mt-4"><?php echo e($product['title']); ?></h2>
                <p class="text-gray-600"><?php echo $product['body_html']; ?></p>
                <a href="/produk/<?php echo e($product['id']); ?>" class="px-3 py-2 bg-blue-700 text-white mt-3 block w-max">View Product</a>

                
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    
   <script>
      function addToCart(variantId, title, image) {
          fetch("/cart/add", {
              method: "POST",
              headers: {
                  "Content-Type": "application/json",
                  "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').getAttribute("content")
              },
              body: JSON.stringify({
                  variant_id: variantId,
                  title: title,
                  image: image,
                  quantity: 1
              })
          })
          .then(response => response.json())
          .then(data => {
              alert(data.message); 
          })
          .catch(error => {
              console.error("Error:", error);
          });
      }
   </script>
</body>
</html>
<?php /**PATH /Users/fajriyannur/localServer/www/shopify/resources/views/produk.blade.php ENDPATH**/ ?>